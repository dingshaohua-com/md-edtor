import { BlockProvider, blockServiceInstance } from "@milkdown/kit/plugin/block";
import { useInstance } from "@milkdown/react";
import { useEffect, useRef, useState, useCallback } from "react";
import blockImg from "../../images/block.svg";
import { autoUpdate, useFloating } from "@floating-ui/react";
import MenuView from "./menu-view";
import { useClickAway } from "ahooks";


export const View = () => {
  const ref = useRef<HTMLDivElement>(null);
  const tooltipProvider = useRef<BlockProvider>(null);
  const floatingRef = useRef<HTMLDivElement>(null);
  const { refs, floatingStyles } = useFloating({
    whileElementsMounted: autoUpdate,
  });

  const [loading, get] = useInstance();

  useEffect(() => {
    const div = ref.current;
    if (loading || !div) return;

    const editor = get();
    if (!editor) return;

    tooltipProvider.current = new BlockProvider({
      ctx: editor.ctx,
      content: div,
    });
    tooltipProvider.current?.update();


    return () => {
      tooltipProvider.current?.destroy();
    };
  }, [loading]);

  const [isOpen, setIsOpen] = useState(false);

  const onClick = () => {
    setIsOpen(true);
    // 显示菜单，并冻结block-view（以解绑形式触发）
    const editor = get();
    if (!editor) return;
    editor.ctx.get(blockServiceInstance.key).unBind();
  };

  const hideMenuView = () => {
    setIsOpen(false);
    // 隐藏block-view和菜单
    const editor = get();
    if (!editor) return;
    if (!editor || !tooltipProvider.current) return;

    const service = editor.ctx.get(blockServiceInstance.key);
    service.bind(editor.ctx, (message) => {
      if (message.type === 'hide') {
        tooltipProvider.current?.hide();
      } else if (message.type === 'show') {
        tooltipProvider.current?.show(message.active);
      }
    });
  };

  // 点击非block区域，让菜单消失
  useClickAway(() => {
    hideMenuView();
  }, [ref, floatingRef]);
  return (
    <>
      <div
        ref={(node) => {
          if (node) {
            refs.setReference(node);
            ref.current = node;
          }
        }}
        className="cursor-pointer items-center justify-center gap-0.5 transition-all duration-200 absolute z-10 transform-gpu"
      >
        <img src={blockImg} alt="block" onClick={onClick} />
      </div>
      {isOpen && (
        <div
          ref={(node) => {
            if (node) {
              refs.setFloating(node);
              floatingRef.current = node;
            }
          }}
          style={{
            ...floatingStyles,
            zIndex: 2,
          }}
        >
          <MenuView onHide={hideMenuView} />
        </div>
      )}
    </>
  );
};
